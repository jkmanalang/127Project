# 127Project
Bartolome, Vallerie <br />
Iguin, Mark Allen <br />
Manalang, John Kenneth <br />
Natividad, John Lim <br />

**Instructions:** <br />
	A. Download the mysql-python connector from https://dev.mysql.com/downloads/connector/python/ <br />
	B. Download the group1_st1l.zip and uncompressed the file in your chosen directory <br />
	C. Open a terminal and go to the directory of the sql file <br />
	D. Log-in to the root user <br />
	E. Run a command source task_record.sql <br />
	F. Open your command prompt and run python app.py or python3 app.py <br />
  	G. Make use of the functions and play around with the database <br />
