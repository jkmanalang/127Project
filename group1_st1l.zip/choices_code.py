import functions

def viewTask ():
	functions.showTasks()

def addCreateTask ():
	functions.createTask()

def editTask ():
	functions.editTask()

def deleteTask ():
	functions.deleteTask()

def markAsDone ():
	functions.markAsDone()

def addCategory ():
	functions.addCategory()

def editCategory ():
	functions.editCategory()

def deleteCategory ():
	functions.deleteCategory()

def viewCategory ():
	functions.viewCategory()

def addTaskToCategory ():
	functions.addTaskToCategory()

	
